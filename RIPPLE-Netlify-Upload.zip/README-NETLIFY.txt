RIPPLE — ready-to-upload Netlify website

1. Extract RIPPLE-Netlify-Upload.zip.
2. Find the folder containing index.html and the assets folder.
3. Drag that entire folder into Netlify's manual deploy area (https://app.netlify.com/drop).
4. Do not upload index.html alone: the assets folder contains the site and 3D libraries.

No build command, API key or environment variable is needed for this upload.

Included: latest cream/pastel theme, interactive 3D globe and compatibility renderer, scroll-driven transformations, household model, policy comparisons, historical evidence snapshots across eight economies, World Bank data refresh requests, CSV/JSON export, and browser-local research notebook saves.

This is a standalone static export. The previous host's private database and ChatGPT authentication do not transfer. Saves are local to each visitor's browser and can be backed up with JSON export. Never clear browser data without exporting experiments you want to keep.

World Bank refresh needs internet access and permission from the upstream service (including CORS). Verified CPI snapshots remain available if refresh fails; other unavailable series show an explicit message. Fonts also load online. The economic model is illustrative, not a causal prediction.

Built for Alokik Mittal. For code edits or server-side multi-user storage, a separate source/backend setup is required.
